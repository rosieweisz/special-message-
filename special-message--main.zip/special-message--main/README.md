# 💌 A Special Message for You
---
### "talking to you is like listening a favorite song on repeat."
✨ 


---
## 🌹 why you?
- [x] You look perfect when you put a smile on your face 
- [x] Best sense of fashion 
- [x] Literally the prettiest girl I know

## 💖 dear, you
> "I'm so glad our paths crossed 🌹✨ may this universe gives us the way to see each other in the future."

**made with 💗 by rosie**


---
**note : i like roses as you do btw (but i like you more)**
